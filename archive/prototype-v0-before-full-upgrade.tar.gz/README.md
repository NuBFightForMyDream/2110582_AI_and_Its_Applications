# Cooling Advisor — Local Prototype

A small Python application that makes the parent/child workflow, five skills, and G1/G2/G3 visible. It runs locally without Supabase or a language-model API key.

**All included data is hand-authored synthetic demonstration data. It is not measured data, a Sustain-LC export, or evidence of actual energy savings.**

## Run

Use Python 3.11 or newer (the development environment was tested with Python 3.12).

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev,integrations]'
python -m cooling_advisor
```

Open [the local dashboard](http://127.0.0.1:8501). On this machine the virtual environment has already been prepared; use `.venv/bin/python -m cooling_advisor` from the project directory.

For exact tested dependency versions, use `requirements.lock.txt` before the editable install with `--no-deps`.

## Try these cases

| Scenario | Expected result |
|---|---|
| Steady load | Select the safe lower-energy alternative; reject the hotter, lower-energy option |
| Peak load | Keep the baseline because the alternative exceeds the demo temperature limit |
| Missing temperature | Stop with insufficient_data |
| Unmatched experiment | Stop with not_supported because the alternative has another initial snapshot |

Use **Agent trace** to see skill loads, parent/child dispatch and guard outcomes. **Agents & skills** shows the actual registered skills and instruction files. Case history and review decisions are persisted locally in `.local/` by default.

## What is implemented

- A real LangGraph with supervisor, data-analysis, cooling-comparison, validation, and finalization phases.
- Deterministic Python role procedures, five loaded skill specifications, guarded tool/dispatch calls and shared tool budgets.
- Independently re-read evidence at G3; temperature/setpoint checks; energy arithmetic; matching scenario/horizon/boundary.
- Streamlit/Plotly dashboard, local case history, idempotency and structured execution events.
- Optional token-protected FastAPI interface and optional Supabase case repository.
- Optional Gemini explanation of the already validated result, explicitly enabled per request.

Default roles are **not autonomous LLM agents**: they run fixed Python procedures in LangGraph. Gemini, when enabled, only explains the validated result. The main numbers and selection always come from Python. The architecture documents describe the broader target system, not a claim that all production features are complete.

## Optional Gemini

Copy `.env.example` to `.env`, set `GEMINI_API_KEY` and a model ID available to your account, then restart the app. Enable **Add a Gemini explanation** to send the synthetic validated case to that API. No call is made by default. API access, quotas and terms depend on the provider/account. If the call fails, the deterministic result remains available. Explanation reference checks do not establish semantic or physical-safety guarantees.

## Optional Supabase

1. Run `supabase/migrations/001_demo_cases.sql` in a Supabase project you control.
2. Set `COOLING_STORAGE=supabase`, `SUPABASE_URL` and the server-only `SUPABASE_SERVICE_ROLE_KEY` in `.env` or hosting secrets.
3. Restart the app. Case results, trace events inside each result, and review records use Supabase instead of SQLite.

The experiment catalog still comes from the packaged synthetic JSON. This adapter does not implement production Supabase Auth, per-user RLS or telemetry ingestion. The supplied tables deny public/anonymous access and use server credentials for one demo operator. Do not publish the demo as a multi-user facility application.

## Optional API

Set `COOLING_API_TOKEN` to a long random value, then run:

```bash
.venv/bin/python -m uvicorn cooling_advisor.api:app --host 127.0.0.1 --port 8000
```

`GET /health` is public. Other routes require `Authorization: Bearer <your token>`. `POST /analysis` also requires an `Idempotency-Key` header. API docs: [local Swagger UI](http://127.0.0.1:8000/docs). This is a shared-token single-operator API, not the production authentication design. The dashboard calls the same Python service directly in this initial prototype.

## Test

```bash
.venv/bin/python -m pytest -q
```

Tests exercise numerical correctness, unsafe alternatives, missing/incompatible evidence, budgets, unauthorized tools, forged proposals, case persistence/idempotency, API behavior and Streamlit interactions. No live external API or Supabase project is required.

## Data and next steps

`offline/generate_demo_fixtures.py` reproduces the four synthetic fixtures; it does not run a simulator. Next, verify one pinned simulator, its temperature observability and energy boundary, then build an authenticated experiment importer. Keep measured, simulated and synthetic sources distinct.

Start with [the architecture index](architecture.md). Current implementation gaps are listed in [Prototype Status](architecture/prototype-status.md). No BMS connector, physical control, live simulator worker or continuous facility monitor is included in this prototype.
