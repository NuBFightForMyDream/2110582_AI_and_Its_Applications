import json
from copy import deepcopy
from pathlib import Path

from .models import Scenario


class Catalog:
    def __init__(self, scenarios: list[Scenario] | None = None):
        if scenarios is None:
            payload = json.loads((Path(__file__).parent / "data" / "scenarios.json").read_text())
            scenarios = [Scenario.model_validate(row) for row in payload["scenarios"]]
        self.scenarios = {item.scenario_id: deepcopy(item) for item in scenarios}

    def get(self, scenario_id: str) -> Scenario:
        if scenario_id not in self.scenarios:
            raise ValueError("UNKNOWN_SCENARIO")
        return self.scenarios[scenario_id].model_copy(deep=True)

    def list(self):
        return [s.model_dump(exclude={"experiments"}) for s in self.scenarios.values()]
