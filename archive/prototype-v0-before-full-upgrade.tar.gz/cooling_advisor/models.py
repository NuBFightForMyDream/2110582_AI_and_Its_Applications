from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class AnalysisRequest(StrictModel):
    scenario_id: str = Field(min_length=1, max_length=60)
    mode: Literal["analyze", "recommend"] = "recommend"
    question: str = Field(default="Compare supported cooling options.", max_length=1000)
    use_gemini: bool = False


class Sample(StrictModel):
    step: int = Field(ge=0)
    interval_hours: float = Field(gt=0)
    cooling_kw: float = Field(ge=0)
    it_kw: float = Field(ge=0)
    max_inlet_c: float | None = None


class Experiment(StrictModel):
    experiment_id: str
    scenario_id: str
    snapshot_id: str
    zone_id: str
    horizon_hours: float = Field(gt=0)
    energy_boundary: Literal["synthetic_it_plus_cooling"]
    source_kind: Literal["synthetic"]
    setpoint_c: float
    samples: list[Sample] = Field(min_length=1, max_length=96)


class Scenario(StrictModel):
    scenario_id: str
    label: str
    description: str
    zone_id: str
    snapshot_id: str
    baseline_id: str
    experiments: list[Experiment]


class DemoPolicy(StrictModel):
    version: str = "synthetic-demo-policy-v1"
    max_inlet_c: float = 27.0
    min_setpoint_c: float = 16.0
    max_setpoint_c: float = 24.0
    tool_budget: int = Field(default=10, ge=0)
    deadline_seconds: float = Field(default=30, gt=0)


class Metrics(StrictModel):
    experiment_id: str
    setpoint_c: float
    cooling_kwh: float
    it_kwh: float
    total_kwh: float
    max_inlet_c: float | None
    feasible: bool
    reasons: list[str] = Field(default_factory=list)
    savings_pct: float | None = None


class Event(StrictModel):
    timestamp: str
    case_id: str
    step: int
    actor: str
    action: str
    status: str
    skill_id: str | None = None
    detail: str = ""


class AnalysisResult(StrictModel):
    case_id: str
    scenario_id: str
    mode: str
    status: Literal["completed", "insufficient_data", "not_supported", "no_feasible_option", "budget_exceeded", "failed"]
    decision: Literal["recommend_change", "no_change", "unavailable"] = "unavailable"
    source_kind: Literal["synthetic"] = "synthetic"
    workflow_mode: str = "deterministic_langgraph"
    policy_version: str
    baseline: Metrics | None = None
    selected: Metrics | None = None
    candidates: list[Metrics] = Field(default_factory=list)
    reason_codes: list[str] = Field(default_factory=list)
    explanation: str = ""
    gemini_explanation: str | None = None
    events: list[Event] = Field(default_factory=list)
    tool_calls: int = 0
