import json
import os
from uuid import uuid4

import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from cooling_advisor.catalog import Catalog
from cooling_advisor.models import AnalysisRequest
from cooling_advisor.skills import SKILLS
from cooling_advisor.storage import ROOT, execute_case, get_store

load_dotenv(ROOT / ".env", override=False)
st.set_page_config(page_title="Cooling Advisor", page_icon="🌡️", layout="wide")


@st.cache_resource
def repository():
    return get_store()


st.title("Cooling Advisor")
st.caption("A small Python prototype · LangGraph workflow · Skills · Guardrails")
st.warning("Synthetic demonstration data only. These values are hand-authored fixtures, not Sustain-LC exports or measurements from a real data center.", icon="🧪")

with st.sidebar:
    st.subheader("Start a case")
    catalog = Catalog()
    scenario = st.selectbox("Scenario", list(catalog.scenarios), format_func=lambda key: catalog.get(key).label)
    st.caption(catalog.get(scenario).description)
    mode = st.radio("Task", ["recommend", "analyze"], format_func=lambda value: "Compare cooling options" if value == "recommend" else "Inspect current conditions")
    use_gemini = st.checkbox("Add a Gemini explanation", value=False, disabled=not bool(os.getenv("GEMINI_API_KEY")))
    if not os.getenv("GEMINI_API_KEY"):
        st.caption("No API key needed. Gemini is optional and currently off.")
    st.caption("Default roles execute Python procedures in a real LangGraph. This is not autonomous LLM tool selection.")
    run = st.button("Run analysis", type="primary", width="stretch")
    st.divider()
    st.caption("Demo policy: maximum inlet 27 °C; setpoint range 16–24 °C. These are fixture-specific limits, not site engineering guidance.")
    st.caption("Storage: " + os.getenv("COOLING_STORAGE", "sqlite") + " · Single local operator")

if run:
    with st.spinner("Supervisor → Data Analyst → Cooling Advisor → G3 → Response"):
        try:
            request = AnalysisRequest(scenario_id=scenario, mode=mode, use_gemini=use_gemini)
            st.session_state["result"] = execute_case(request, str(uuid4()), repository()).model_dump(mode="json")
        except Exception:
            st.session_state.pop("result", None)
            st.error("The case could not be saved. Check local storage or your configured Supabase connection.")

result_tab, trace_tab, skills_tab, history_tab = st.tabs(["Result", "Agent trace", "Agents & skills", "Case history"])
result = st.session_state.get("result")

with result_tab:
    if not result:
        st.info("Choose a scenario and select Run analysis. Start with Steady load.")
        st.markdown("**Flow:** Supervisor (S1) → Data Analyst (S2/S3) → Cooling Advisor (S4) → G3 → Supervisor (S5)")
    else:
        st.caption(f"Case {result['case_id']} · {result['scenario_id']} · source: synthetic")
        if result["status"] == "completed":
            st.success(result["explanation"])
        else:
            st.error(result["explanation"])
        baseline, selected = result.get("baseline"), result.get("selected")
        if baseline:
            columns = st.columns(3)
            columns[0].metric("Baseline total energy", f"{baseline['total_kwh']:.2f} kWh")
            if selected:
                columns[1].metric("Selected total energy", f"{selected['total_kwh']:.2f} kWh")
                pct = selected["savings_pct"]
                columns[2].metric("Synthetic energy reduction", f"{pct:.1f}%" if pct is not None else "Undefined")
            else:
                columns[1].metric("Baseline cooling energy", f"{baseline['cooling_kwh']:.2f} kWh")
                columns[2].metric("Baseline max inlet", f"{baseline['max_inlet_c']:.1f} °C" if baseline["max_inlet_c"] is not None else "Missing")
        if result["candidates"]:
            frame = pd.DataFrame(result["candidates"])
            chart = px.bar(frame, x="experiment_id", y="total_kwh", color="feasible",
                           color_discrete_map={True: "#0f766e", False: "#b45309"},
                           labels={"experiment_id": "Recorded option", "total_kwh": "Total energy (kWh)", "feasible": "Passes demo limits"})
            st.plotly_chart(chart, width="stretch")
            st.dataframe(frame[["experiment_id", "setpoint_c", "cooling_kwh", "it_kwh", "total_kwh", "max_inlet_c", "feasible", "reasons"]], hide_index=True, width="stretch")
        st.caption("A rejected option may use less energy but exceed the configured temperature limit. G3 excludes it from selection.")
        if result.get("gemini_explanation"):
            with st.expander("Optional Gemini explanation"):
                st.write(result["gemini_explanation"])
                st.caption("Model-generated prose. Numeric cards and selection remain Python-validated; explanation faithfulness is not a physical-safety guarantee.")
        st.download_button("Download case JSON", data=json.dumps(result, indent=2), file_name="cooling-case.json", mime="application/json")
        if st.button("Mark this case for review"):
            try:
                repository().decision(result["case_id"], "mark_for_review")
                st.success("Review intent recorded. No equipment command was issued.")
            except Exception:
                st.error("Could not persist the review record.")

with trace_tab:
    st.subheader("What happened in this case?")
    if result:
        st.caption(f"{result['tool_calls']} guarded tool/dispatch calls · {result['workflow_mode']}")
        st.dataframe(pd.DataFrame(result["events"])[["step", "actor", "skill_id", "action", "status", "detail"]], hide_index=True, width="stretch")
    else:
        st.info("Run a case to see skill loads, parent/child handoffs and G1/G2/G3 events.")

with skills_tab:
    st.subheader("Three roles, five skills")
    st.dataframe(pd.DataFrame([{"Agent": skill.owner, "Skill": f"{skill.id} · {skill.name}", "Tools": ", ".join(skill.tools) or "None (composition)", "Version": skill.version} for skill in SKILLS.values()]), hide_index=True, width="stretch")
    for skill in SKILLS.values():
        with st.expander(f"{skill.id} · {skill.name}"):
            st.markdown(skill.instructions())

with history_tab:
    try:
        recent = repository().recent()
        st.dataframe(pd.DataFrame(recent), hide_index=True, width="stretch")
        if recent:
            case_id = st.selectbox("Saved case", [row["case_id"] for row in recent])
            if st.button("Open saved case"):
                st.session_state["result"] = repository().get(case_id).model_dump(mode="json")
                st.rerun()
    except Exception:
        st.error("History is unavailable. Check the configured storage connection.")
