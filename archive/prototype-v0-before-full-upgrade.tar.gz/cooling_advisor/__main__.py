import subprocess
import sys
from pathlib import Path


def main():
    dashboard = Path(__file__).parent / "dashboard.py"
    raise SystemExit(subprocess.call([sys.executable, "-m", "streamlit", "run", str(dashboard),
                                     "--server.address=127.0.0.1", "--server.port=8501",
                                     "--server.headless=true", *sys.argv[1:]]))


if __name__ == "__main__":
    main()
