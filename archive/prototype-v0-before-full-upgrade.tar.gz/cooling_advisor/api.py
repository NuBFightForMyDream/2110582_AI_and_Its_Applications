"""Optional token-protected, single-operator FastAPI interface."""
import os
import secrets
from functools import lru_cache
from typing import Annotated, Literal

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from .catalog import Catalog
from .models import AnalysisRequest
from .storage import ROOT, ConflictError, execute_case, get_store

load_dotenv(ROOT / ".env", override=False)
app = FastAPI(title="Cooling Advisor — local prototype", version="0.1.0")
bearer = HTTPBearer(auto_error=False)


def authorize(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]):
    token = os.getenv("COOLING_API_TOKEN", "")
    if not token:
        raise HTTPException(503, "Set COOLING_API_TOKEN before using the API")
    if credentials is None or not secrets.compare_digest(credentials.credentials, token):
        raise HTTPException(401, "Invalid bearer token")


@lru_cache
def repository():
    return get_store()


@app.get("/health")
def health():
    return {"status": "ok", "mode": "synthetic_demo"}


@app.get("/catalog", dependencies=[Depends(authorize)])
def catalog():
    return Catalog().list()


@app.post("/analysis", dependencies=[Depends(authorize)])
def analyze(request: AnalysisRequest, idempotency_key: Annotated[str, Header(min_length=1, max_length=120)]):
    try:
        Catalog().get(request.scenario_id)
    except ValueError:
        raise HTTPException(422, "Unknown scenario")
    try:
        return execute_case(request, idempotency_key, repository()).model_dump(mode="json")
    except ConflictError as exc:
        raise HTTPException(409, str(exc))
    except Exception:
        raise HTTPException(503, "Storage or workflow service unavailable")


@app.get("/cases/{case_id}", dependencies=[Depends(authorize)])
def case(case_id: str):
    try:
        return repository().get(case_id).model_dump(mode="json")
    except KeyError:
        raise HTTPException(404, "Unknown case")
    except ConflictError as exc:
        raise HTTPException(409, str(exc))


@app.get("/cases/{case_id}/events", dependencies=[Depends(authorize)])
def events(case_id: str):
    return case(case_id)["events"]


class Decision(BaseModel):
    action: Literal["acknowledge", "mark_for_review", "dismiss"]


@app.post("/cases/{case_id}/decision", dependencies=[Depends(authorize)])
def decision(case_id: str, payload: Decision):
    case(case_id)
    repository().decision(case_id, payload.action)
    return {"recorded": True, "action": payload.action, "equipment_command": False}
