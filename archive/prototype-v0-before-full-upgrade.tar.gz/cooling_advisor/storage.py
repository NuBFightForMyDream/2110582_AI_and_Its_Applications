"""Single-operator case persistence: SQLite by default; optional Supabase."""
import hashlib
import json
import os
import sqlite3
from pathlib import Path
from uuid import uuid4

from .models import AnalysisRequest, AnalysisResult

ROOT = Path(__file__).resolve().parent.parent
OWNER = "local-demo-operator"


class ConflictError(Exception):
    pass


def request_hash(request):
    return hashlib.sha256(json.dumps(request.model_dump(), sort_keys=True).encode()).hexdigest()


class SQLiteStore:
    def __init__(self, path=None):
        self.path = Path(path or os.getenv("COOLING_SQLITE_PATH", str(ROOT / ".local" / "cooling-advisor.sqlite3")))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS cases (
                    id TEXT PRIMARY KEY, owner_id TEXT NOT NULL,
                    dedupe_key TEXT NOT NULL, request_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    result TEXT, UNIQUE(owner_id, dedupe_key)
                );
                CREATE TABLE IF NOT EXISTS decisions (
                    case_id TEXT NOT NULL, action TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(case_id, action)
                );
            """)

    def connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def reserve(self, request, key):
        digest = request_hash(request)
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM cases WHERE owner_id=? AND dedupe_key=?", (OWNER, key)).fetchone()
            if row:
                if row["request_hash"] != digest:
                    raise ConflictError("Idempotency key already belongs to a different request")
                if row["result"] is None:
                    raise ConflictError("Case is in progress or was interrupted; use a new submission key")
                return row["id"], AnalysisResult.model_validate_json(row["result"])
            case_id = str(uuid4())
            con.execute("INSERT INTO cases(id,owner_id,dedupe_key,request_hash) VALUES(?,?,?,?)", (case_id, OWNER, key, digest))
            return case_id, None

    def finish(self, result):
        with self.connect() as con:
            con.execute("UPDATE cases SET result=? WHERE id=? AND owner_id=?", (result.model_dump_json(), result.case_id, OWNER))

    def get(self, case_id):
        with self.connect() as con:
            row = con.execute("SELECT result FROM cases WHERE id=? AND owner_id=?", (case_id, OWNER)).fetchone()
        if not row:
            raise KeyError(case_id)
        if row["result"] is None:
            raise ConflictError("Case is in progress or interrupted")
        return AnalysisResult.model_validate_json(row["result"])

    def recent(self):
        with self.connect() as con:
            rows = con.execute("SELECT id,created_at,result FROM cases WHERE owner_id=? ORDER BY rowid DESC LIMIT 20", (OWNER,)).fetchall()
        return [{"case_id": r["id"], "created_at": r["created_at"], "status": json.loads(r["result"])["status"] if r["result"] else "in_progress_or_interrupted"} for r in rows]

    def decision(self, case_id, action):
        self.get(case_id)
        with self.connect() as con:
            con.execute("INSERT OR IGNORE INTO decisions(case_id,action) VALUES(?,?)", (case_id, action))


class SupabaseStore:
    def __init__(self):
        from supabase import ClientOptions, create_client
        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        if not url or not key:
            raise RuntimeError("Configure server-side Supabase URL and service role key")
        self.client = create_client(url, key, options=ClientOptions(postgrest_client_timeout=10))

    def reserve(self, request, key):
        digest = request_hash(request)
        case_id = str(uuid4())
        try:
            self.client.table("cooling_demo_cases").insert({"id": case_id, "owner_id": OWNER, "dedupe_key": key, "request_hash": digest}).execute()
            return case_id, None
        except Exception:
            rows = self.client.table("cooling_demo_cases").select("*").eq("owner_id", OWNER).eq("dedupe_key", key).execute().data
            if not rows:
                raise
            row = rows[0]
            if row["request_hash"] != digest:
                raise ConflictError("Idempotency key belongs to a different request")
            if row.get("result") is None:
                raise ConflictError("Case is in progress or interrupted")
            return row["id"], AnalysisResult.model_validate(row["result"])

    def finish(self, result):
        self.client.table("cooling_demo_cases").update({"result": result.model_dump(mode="json")}).eq("id", result.case_id).eq("owner_id", OWNER).execute()

    def get(self, case_id):
        rows = self.client.table("cooling_demo_cases").select("result").eq("id", case_id).eq("owner_id", OWNER).execute().data
        if not rows:
            raise KeyError(case_id)
        if rows[0]["result"] is None:
            raise ConflictError("Case is in progress or interrupted")
        return AnalysisResult.model_validate(rows[0]["result"])

    def recent(self):
        rows = self.client.table("cooling_demo_cases").select("id,created_at,result").eq("owner_id", OWNER).order("created_at", desc=True).limit(20).execute().data
        return [{"case_id": r["id"], "created_at": r["created_at"], "status": (r["result"] or {}).get("status", "in_progress_or_interrupted")} for r in rows]

    def decision(self, case_id, action):
        self.get(case_id)
        self.client.table("cooling_demo_decisions").upsert({"case_id": case_id, "action": action}, on_conflict="case_id,action").execute()


def get_store():
    if os.getenv("COOLING_STORAGE", "sqlite") == "supabase":
        return SupabaseStore()
    return SQLiteStore()


def execute_case(request: AnalysisRequest, key: str, store, **engine_options):
    from .engine import run_analysis
    case_id, existing = store.reserve(request, key)
    if existing:
        return existing
    result = run_analysis(request, case_id=case_id, **engine_options)
    store.finish(result)  # Do not report stored success if persistence fails.
    return result
