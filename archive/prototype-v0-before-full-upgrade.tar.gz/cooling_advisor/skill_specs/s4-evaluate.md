# S4 — Evaluate Cooling Options
Owner: cooling_advisor. Version: 0.1.0-demo.

Retrieve only experiments with the same scenario, initial snapshot, zone, horizon, source and energy boundary. Include the baseline in a supported comparison. Calculate with Python and propose an evidence ID. G3 independently re-reads evidence and verifies selection. Missing matching alternatives is not_supported; the baseline remaining best is no_change.
