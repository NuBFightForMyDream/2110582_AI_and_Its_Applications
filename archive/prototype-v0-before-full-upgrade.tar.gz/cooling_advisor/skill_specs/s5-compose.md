# S5 — Compose Recommendation
Owner: supervisor. Version: 0.1.0-demo.

Explain only validated results and their limitations. Numerical tables are built by Python. State that all fixture data is synthetic and is not a Sustain-LC export or measured site data. An optional Gemini explanation must reference only the supplied evidence IDs, issue no equipment commands, and invent no measurements. If it fails, retain the deterministic explanation.
