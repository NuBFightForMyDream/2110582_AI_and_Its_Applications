# S3 — Analyze Performance
Owner: data_analyst. Version: 0.1.0-demo.

Integrate interval-average power over valid hours. Report cooling, IT and total energy separately. Preserve units and evidence IDs. Never infer maximum inlet temperature from an average. Demo results describe synthetic fixtures, not a real facility.
