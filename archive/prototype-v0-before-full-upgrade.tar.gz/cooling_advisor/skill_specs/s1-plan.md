# S1 — Plan Analysis
Owner: supervisor. Version: 0.1.0-demo.

Respect the validated request mode and server-authorized scope. Dispatch data inspection first. Dispatch cooling comparison only when inspection passed and alternatives were requested. Return typed limitations when evidence is missing. In demo mode this procedure is implemented by deterministic graph routing.
