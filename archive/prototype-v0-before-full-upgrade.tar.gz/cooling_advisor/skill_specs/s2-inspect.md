# S2 — Inspect Cooling Data
Owner: data_analyst. Version: 0.1.0-demo.

Read the baseline from the selected catalog. Verify complete contiguous intervals, finite values, source scope and maximum-inlet-temperature observability. Stop with insufficient_data if required evidence is missing. Every tool call uses the guarded gateway.
