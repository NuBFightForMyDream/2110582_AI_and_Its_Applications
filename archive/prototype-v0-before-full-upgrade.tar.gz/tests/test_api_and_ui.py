from pathlib import Path

from fastapi.testclient import TestClient

from cooling_advisor.api import app, repository


def test_api_authentication_and_case_workflow(tmp_path, monkeypatch):
    monkeypatch.setenv("COOLING_API_TOKEN", "test-token-not-for-deployment")
    monkeypatch.setenv("COOLING_STORAGE", "sqlite")
    monkeypatch.setenv("COOLING_SQLITE_PATH", str(tmp_path / "api.db"))
    repository.cache_clear()
    client = TestClient(app)
    assert client.get("/health").status_code == 200
    assert client.get("/catalog").status_code == 401
    headers = {"Authorization": "Bearer test-token-not-for-deployment", "Idempotency-Key": "test-one"}
    assert client.get("/catalog", headers=headers).status_code == 200
    response = client.post("/analysis", headers=headers, json={"scenario_id": "steady"})
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "completed"
    assert client.post("/analysis", headers=headers, json={"scenario_id": "steady"}).json()["case_id"] == payload["case_id"]
    assert client.post("/analysis", headers=headers, json={"scenario_id": "peak"}).status_code == 409
    assert client.get(f"/cases/{payload['case_id']}/events", headers=headers).json()
    assert client.post(f"/cases/{payload['case_id']}/decision", headers=headers, json={"action": "mark_for_review"}).json()["equipment_command"] is False
    assert client.post("/analysis", headers=headers, json={"scenario_id": "unknown"}).status_code == 422
    repository.cache_clear()


def test_streamlit_supported_and_blocked_scenario(tmp_path, monkeypatch):
    from streamlit.testing.v1 import AppTest
    monkeypatch.setenv("COOLING_STORAGE", "sqlite")
    monkeypatch.setenv("COOLING_SQLITE_PATH", str(tmp_path / "ui.db"))
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    path = Path(__file__).parents[1] / "cooling_advisor/dashboard.py"
    app_test = AppTest.from_file(str(path), default_timeout=20).run()
    assert not app_test.exception
    app_test.sidebar.button[0].click().run()
    assert not app_test.exception
    assert app_test.session_state["result"]["selected"]["experiment_id"] == "steady-19"
    app_test.sidebar.selectbox[0].select("missing").run()
    app_test.sidebar.button[0].click().run()
    assert not app_test.exception
    assert app_test.session_state["result"]["status"] == "insufficient_data"
