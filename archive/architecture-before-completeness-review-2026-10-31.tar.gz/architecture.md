# Cooling Advisor Agent — Architecture

Status: design only. The application analyzes cooling data and recommends supported operating alternatives.

## Start with these three pages

1. [Overview](docs/architecture/01-overview.md) — what the system does and the overall flow.
2. [Agents](docs/architecture/02-agents.md) — what the supervisor and its two specialists do.
3. [Guardrails](docs/architecture/03-guardrails.md) — where G1, G2, and G3 check the workflow.

## Technical details — read when needed

| Topic | Page |
|---|---|
| Data sources, simulator choice, and experiment compatibility | [Data and Simulator](docs/architecture/04-data-and-simulator.md) |
| FastAPI endpoints, agent state, and Supabase tables | [Backend and Storage](docs/architecture/05-backend-and-storage.md) |
| Logs, case history, and evaluation | [Monitoring and Evaluation](docs/architecture/06-monitoring-and-evaluation.md) |
| Python stack, hosting, code layout, and build order | [Deployment and Roadmap](docs/architecture/07-deployment-and-roadmap.md) |

Each page covers one topic. The MVP uses precomputed experiments; the operator decides whether to adopt a validated recommendation.

Previous designs are preserved in `archive/`.
