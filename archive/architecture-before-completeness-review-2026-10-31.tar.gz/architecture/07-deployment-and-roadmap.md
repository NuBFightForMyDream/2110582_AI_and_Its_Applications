# 07 — Deployment and Roadmap

[Architecture index](../../architecture.md)

Use this page when choosing hosting, organizing code, or starting implementation.

## Technology and hosting

| Component | Technology | Responsibility | Initial deployment |
|---|---|---|---|
| Dashboard | Streamlit + Plotly | Case creation, charts, comparisons, and monitoring views | Streamlit Community Cloud |
| Backend | FastAPI + Pydantic | Authentication, authorization, input/output contracts, and orchestration | Render web service |
| Agent workflow | LangGraph for Python | Supervisor routing, specialist execution, and termination paths | Backend process |
| Language model | Configurable Gemini API client | Tool selection and explanations | External API |
| Analysis | pandas + NumPy | Data-quality checks, energy integration, and baseline comparison | Backend process |
| Database | Supabase PostgreSQL via `supabase-py` | Telemetry, experiments, cases, and structured events | Supabase |
| File storage | Supabase Storage | Source CSV/Parquet files and larger result artifacts | Supabase |
| Offline simulation | Simulator-specific Python environment | Produce versioned, repeatable experiment results | Developer machine initially |
| Monitoring | Python structured logging + Supabase + Streamlit | Operational events, run history, and guardrail outcomes | Backend and dashboard |

Use the Python version and native dependencies supported by the selected simulator; do not assume the web service and simulator can share one environment. Pin tested dependencies when implementation starts.

Free service tiers are a demo deployment option, subject to their current quotas, availability, sleep behavior, and terms. They are not an always-on BMS monitoring service. Check current plan terms before deployment; no paid subscription or hosting account is configured by this document.

## Proposed code layout

This is a future implementation layout, not a claim that these files already exist.

```text
project/
├── architecture.md                 # Short reading index
├── docs/
│   └── architecture/              # Focused design pages
├── archive/                         # Recoverable pre-redesign documents
├── Midterm Project /                # Original proposal PDF, unchanged
├── dashboard/
│   └── app.py                       # Streamlit user and monitoring views
├── backend/
│   └── app/
│       ├── main.py                  # FastAPI endpoints and G1
│       ├── schemas.py               # Pydantic contracts
│       ├── auth.py                  # Identity and scope enforcement
│       ├── agents/
│       │   ├── graph.py             # State, routing, and termination
│       │   ├── supervisor.py
│       │   ├── data_analyst.py
│       │   └── cooling_advisor.py
│       ├── skills/                  # English procedural specifications
│       ├── tools/
│       │   ├── gateway.py           # G2 wrapper and tool registry
│       │   ├── telemetry.py
│       │   ├── baseline.py
│       │   └── experiments.py
│       ├── guardrails/
│       │   ├── context.py           # Trusted run scope and budgets
│       │   └── recommendation.py    # G3 and response consistency
│       ├── repositories/            # Scoped Supabase access
│       └── monitoring/              # Structured events and persistence
├── offline/
│   ├── simulator_adapter.py         # One verified simulator initially
│   ├── generate_experiments.py
│   └── export_results.py
├── configs/                         # Versioned policies and scenarios
├── supabase/
│   └── migrations/                  # Tables and access policies
└── tests/                           # Meaningful tool, guardrail, and workflow checks
```

## Implementation order

1. Verify the selected simulator and energy/temperature definitions. Record the feasibility-gate outcome before claiming an optimization opportunity.
2. Export one scenario and compatible alternatives; build the Supabase schema and scoped import path.
3. Implement deterministic data-quality checks, energy calculations, comparison, and G1/G2/G3. Prove the result without an LLM first.
4. Add the Data Analyst, then the Cooling Advisor, then supervisor orchestration using validated contracts.
5. Add Streamlit case views and monitoring. Verify interrupted requests, repeat submissions, and recovery behavior.
6. Deploy a limited demo with precomputed results. Check current hosting and model-tier terms and test native dependencies separately before considering live simulation.

## References

- SustainDC: https://github.com/HewlettPackard/dc-rl
- Sustain-LC: https://github.com/HewlettPackard/sustain-lc
- LangGraph: https://docs.langchain.com/oss/python/langgraph/graph-api
- Supervisor/subagents: https://docs.langchain.com/oss/python/langchain/multi-agent/subagents
- FastAPI: https://fastapi.tiangolo.com/
- Supabase Python: https://supabase.com/docs/reference/python/introduction
- Supabase access policies: https://supabase.com/docs/guides/database/postgres/row-level-security
- Streamlit hosting: https://docs.streamlit.io/deploy/streamlit-community-cloud
- Render deployment constraints: https://render.com/docs/free
