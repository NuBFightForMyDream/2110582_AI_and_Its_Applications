# 02 — Agents

[Architecture index](../../architecture.md)

This page explains the supervisor, its two specialists, and their skills.

## Agent responsibilities

The supervisor communicates with the user. Specialists return structured results to the supervisor and have narrowly assigned tools. All three can use the same LLM model through a shared client abstraction; they differ in role instructions, skills, and tool access.

| Agent | Responsibility | Allowed capabilities | Output |
|---|---|---|---|
| Supervisor | Interpret the request, choose the next task, coordinate specialists, and explain validated results | Invoke the two specialists and inspect case status | Structured task plan and explanation tied to validated evidence |
| Data Analyst | Inspect data quality, summarize current conditions, and compare a compatible baseline | `read_telemetry`, `inspect_data_quality`, `compute_baseline` | `DataAnalysisResult` |
| Cooling Advisor | Retrieve supported alternatives and compare their recorded outcomes | `lookup_experiments`, `compare_candidates` | `CandidateResults` with evidence IDs |

## Parent and child flow

```mermaid
flowchart TD
    USER["Operator"]
    SUP["Supervisor agent<br/>Coordinates the case and explains the result"]
    DA["Data Analyst<br/>Inspects current conditions and data quality"]
    CA["Cooling Advisor<br/>Compares supported operating alternatives"]
    USER -->|"Question"| SUP
    SUP -->|"1. Analyze"| DA
    DA -->|"2. Analysis result"| SUP
    SUP -->|"3. Evaluate options"| CA
    CA -->|"4. Candidate results"| SUP
    SUP -->|"5. Validated response"| USER
```

This diagram focuses on agent responsibilities. The [Guardrails page](03-guardrails.md) expands the checks around this workflow. For a current-state question, the supervisor can finish after the Data Analyst result has been validated.

## Skills

Skills are procedural specifications used by the agents. They are not additional agents, and they do not require an embedding store or retrieval system.

| Skill | Owner | Input | Required procedure | Output / stop condition |
|---|---|---|---|---|
| Inspect Cooling Data | Data Analyst | Authorized zone, time range, dataset reference | Read bounded data; check timestamp meaning, units, coverage, and required fields | Quality report; stop if required evidence is unavailable |
| Analyze Cooling Performance | Data Analyst | Validated telemetry and baseline definition | Integrate energy; summarize defined temperature metrics; compare compatible windows | Facts and hypotheses kept separate; no causal claim from correlation alone |
| Evaluate Cooling Options | Cooling Advisor | Scenario, snapshot, baseline ID, horizon, and policy | Retrieve comparable runs; use Python comparisons; return candidate and evidence IDs | Candidate results or `not_supported` / `no_feasible_option` |
| Compose Recommendation | Supervisor | Validated findings and candidate selection | Explain the recommendation, trade-offs, provenance, and limitations | Schema-valid explanation tied to approved result fields |

Each skill specification should declare its name/version, trigger, input/output schema, allowed tools, ordered procedure, success criteria, and stop conditions. Behavior-critical checks must also be enforced in Python.

Next: [03 — Guardrails](03-guardrails.md)
