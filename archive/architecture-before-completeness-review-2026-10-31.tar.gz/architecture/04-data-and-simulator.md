# 04 — Data and Simulator

[Architecture index](../../architecture.md)

Use this page when selecting a simulator, preparing data, or exporting experiments.

## Data sources

- **Simulation experiments:** export input conditions, settings, time-series outputs, and measured-within-simulation energy values from reproducible runs.
- **Public measured datasets:** import selected telemetry for exploratory analysis. Dataset provenance and equipment scope must be explicit.
- **Site telemetry, later:** ingest authorized exports or a read-only BMS integration after establishing tag mappings, units, timestamps, and equipment scope.

Store `source_kind` as `simulated` or `measured` on every dataset and result. A measured dataset and a simulation are separate evidence sources; sharing a facility name does not make them interchangeable.

## Simulator selection

SustainDC (`HewlettPackard/dc-rl`) is the initial air/HVAC simulator candidate inherited from the existing project. Sustain-LC (`HewlettPackard/sustain-lc`) is a separate candidate for liquid cooling. Select and validate one before generating the MVP experiment catalog. The adapters, observations, and actions are different.

Earlier project notes, summarized in [the pre-split architecture](../../archive/architecture-before-split-2026-10-31.md), report unresolved issues for one older SustainDC configuration: a weak cooling-energy trade-off, differences in IT energy, temperature observability, and potentially incomplete power accounting. These are historical observations, not verified claims about the current upstream version. Reproduce or reject them using a pinned commit and recorded configuration.

**Feasibility gate:** compare fixed settings and an appropriate rule-based baseline under identical workload, weather, initial state, duration, configuration, and seeds. Check the modeled temperature variables and energy boundary. If one setting dominates all alternatives, report that result; do not manufacture an optimization benefit or modify limits solely to make the advisor appear useful.

## Experiment contract

Each experiment must identify:

```text
experiment_id, scenario_id, initial_snapshot_id
source_kind, simulator_name, simulator_commit, config_hash
workload_trace_id, weather_trace_id, seed_manifest
action_history_or_candidate_plan, setting_units
evaluation_start, evaluation_end, timestep_definition
temperature_metric_definition, temperature_observability
energy_boundary, baseline_experiment_id
policy_version, artifact_reference, artifact_hash
```

Compare only experiments with matching relevant conditions and a common evaluation horizon and energy boundary. Apply tolerances only when explicitly defined and validated. Missing matches return `not_supported`; the agent must not present a nearby experiment as an exact simulation of a new request.

For average power samples, energy is `sum(power_kW * interval_hours)` over valid intervals. For instantaneous samples, use a documented integration rule. Handle irregular timestamps, gaps, and cumulative-meter resets explicitly. A temperature average cannot establish a maximum-rack temperature constraint. An unavailable required metric makes that constraint unverifiable.

## Source repositories

- [SustainDC: air/HVAC candidate](https://github.com/HewlettPackard/dc-rl)
- [Sustain-LC: liquid-cooling candidate](https://github.com/HewlettPackard/sustain-lc)

Database table responsibilities are listed in [Backend and Storage](05-backend-and-storage.md).

Next: [05 — Backend and Storage](05-backend-and-storage.md)
