# 03 — Guardrails

[Architecture index](../../architecture.md)

This page shows exactly where G1, G2, and G3 run and what happens when a check fails.

## Check locations

```mermaid
flowchart TD
    REQUEST["POST /analysis"]
    G1["G1: Request guard<br/>Identity, access, schema, scope"]
    MOM["Supervisor<br/>Plan and dispatch"]
    DATA["Data Analyst<br/>Inspect and analyze"]
    COOL["Cooling Advisor<br/>Compare supported alternatives"]
    G2["G2: Tool-call guard<br/>Allowlist, arguments, scope, budget, timeout"]
    TOOL["Python tools<br/>Supabase reads and calculations"]
    G3["G3: Recommendation validator<br/>Evidence, comparability, limits, arithmetic"]
    CHECK{"Validation passed?"}
    FINAL["Finalize response<br/>Trusted numbers + supervisor explanation"]
    STOP["Return reason<br/>Missing data, unsupported, or no feasible option"]

    REQUEST --> G1 --> MOM
    MOM --> DATA
    DATA -->|"Validated analysis result"| COOL
    DATA <-->|"Call / result"| G2
    COOL <-->|"Call / result"| G2
    G2 <--> TOOL
    COOL --> G3 --> CHECK
    CHECK -->|"Yes"| FINAL
    CHECK -->|"No"| STOP
```

This is the full-recommendation path. A current-state question can terminate after Data Analyst execution and evidence validation. The supervisor remains the coordinator when moving between specialist nodes; the diagram abbreviates its dispatch transitions.

1. Validate the request and create trusted context.
2. The supervisor determines whether analysis alone or a recommendation is required.
3. The Data Analyst retrieves data through guarded tools and produces a quality report and calculated facts.
4. If data is sufficient and alternatives are requested, the Cooling Advisor retrieves comparable experiments and proposes candidate IDs.
5. The Python validator independently retrieves referenced results, checks constraints, and recomputes the comparison.
6. The supervisor writes an explanation. The response builder attaches the validated settings, numbers, units, and evidence references.
7. Validate the final response schema and its references before returning it. Numerical facts shown in tables and charts come from the validated result, not newly generated prose. Reject or repair an explanation that contradicts those facts within the configured retry budget.

Insufficient evidence is a valid terminal outcome. No node may silently replace missing inputs with invented observations or claim that a simulated result is a realized saving.

## Guard responsibilities

| Guard | Implementation boundary | Required checks | Failure behavior |
|---|---|---|---|
| G1 | FastAPI dependencies + Pydantic request model | Verified user identity; zone access; valid time range; request-size and request-rate limits | Reject before invoking the graph |
| G2 | A common wrapper around every registered tool | Tool allowlist; input schema; server-enforced data scope; bounded queries; shared budget; per-call and overall deadlines; output schema | Do not execute a rejected call; record a typed error |
| G3 | Deterministic Python validator and final response assembly | Evidence existence and provenance; compatible scenario/horizon; temperature observability; configured operating limits; energy scope; arithmetic; output consistency | Return a reasoned non-recommendation or request bounded re-analysis |

- Tool names are mapped to registered Python functions. Model-generated SQL, shell commands, or arbitrary URLs are not execution interfaces.
- Inputs, tool responses, and model outputs have explicit schemas. Text in telemetry labels or uploaded data cannot grant tool privileges or change policy.
- Permissions, hard limits, and equipment constraints come from versioned configuration approved for the scenario/site. Do not hardcode one temperature limit for all equipment or transfer air-inlet limits to liquid-coolant variables.
- Enforce deadlines and cancellation around model and tool calls, plus a graph-step limit. These are distinct controls; a graph-step limit alone does not cap API calls or elapsed time.
- Reserve shared usage budgets atomically if execution becomes concurrent. A failed call or retry still consumes the relevant budget.
- Use server-validated identity and scope. Protect Supabase tables and storage with appropriate access policies; privileged service keys bypass normal RLS protections and therefore require explicit backend authorization.
- Store secrets only in server-side secret configuration. Redact tokens and sensitive telemetry from logs and model requests.
- The MVP has no actuator tool. Connecting a live BMS for reads does not authorize equipment writes. Any future control service needs fresh-state checks, equipment-specific interlocks, operator authorization, and rollback behavior in a separate implementation.

Next: [04 — Data and Simulator](04-data-and-simulator.md)
