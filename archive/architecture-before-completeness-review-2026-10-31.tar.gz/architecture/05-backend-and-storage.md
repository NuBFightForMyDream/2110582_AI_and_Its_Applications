# 05 — Backend and Storage

[Architecture index](../../architecture.md)

Use this page when implementing FastAPI, case state, and Supabase storage.

## API contracts

Proposed endpoints:

```text
POST /analysis               Create and execute a bounded analysis case
GET  /cases/{case_id}        Read authorized case status and result
GET  /cases/{case_id}/events Read authorized monitoring events
GET  /health                Lightweight process-health response
```

The MVP uses bounded request execution. A response includes a `case_id`. A timeout is recorded as a terminal failure; retries use an idempotency key to avoid duplicate case writes. An optional external worker and durable job queue require a later design. A `job_id` or an in-process background task alone does not provide durable execution on a sleeping/restarting free host.

```text
AnalysisResponse
  case_id
  status: completed | insufficient_data | not_supported |
          no_feasible_option | budget_exceeded | failed
  source_kind, scenario_id, policy_version
  validated_facts, baseline, selected_candidate
  evidence_ids, explanation, limitations
```

A successful analysis can conclude that the existing setting is best or that no supported change improves energy use. Such outcomes must remain visible rather than being rewritten as a positive recommendation.

## Agent state and trusted context

```text
RunContext (server-created; read-only to model-generated content)
  case_id, user_id, authorized_zone_ids, policy_version
  deadline, llm_call_budget, tool_call_budget

AnalysisState (validated updates across graph nodes)
  request, plan, data_analysis, candidate_results
  validation_result, response, evidence_ids, execution_status
```

Tool-usage reservation, elapsed-time checks, and authorization are enforced by code using the trusted context. Shared quotas cover the supervisor and both specialists, including retries. Persist case state explicitly; an in-memory LangGraph state or Streamlit session is not restart recovery by itself.

## Supabase tables and files

| Table / store | Purpose |
|---|---|
| `datasets` | Provenance, schema version, units, source kind, and storage references |
| `telemetry` | Timestamped, scoped metric samples and quality flags; import only needed subsets |
| `scenarios` | Configuration, initial state, traces, duration, and seed references |
| `experiment_runs` | Candidate settings, baseline links, outputs, manifest, and metric definitions |
| `policies` | Versioned limits, allowed ranges, comparison rules, and budgets |
| `cases` | Owner/scope, lifecycle status, validated state, and final response |
| `agent_events` | Step-level execution, model usage, tool calls, and errors |
| `guardrail_events` | Guard name, decision, reason codes, and evidence references |
| Storage buckets | Larger CSV/Parquet artifacts; database rows retain hashes and references |

Use stable IDs and explicit foreign keys. Keep experiment artifacts immutable once referenced by a completed case. Limit log retention and avoid importing entire large public datasets into a small free database.

Next: [06 — Monitoring and Evaluation](06-monitoring-and-evaluation.md)
