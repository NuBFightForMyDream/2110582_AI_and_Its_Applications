# 01 — Overview

[Architecture index](../../architecture.md)

Start here. This page explains the product, its scope, and the overall flow.

## What the application does

An operator asks whether a cooling zone has a supported, lower-energy operating option. The application inspects the data, compares compatible experiments, and returns an explanation with traceable results. The operator decides whether to investigate or adopt a recommendation.

## System flow

```mermaid
flowchart LR
    USER["Operator"] --> UI["Streamlit dashboard"]
    UI <--> API["FastAPI backend"]
    API <--> AI["Python agent workflow"]
    AI <--> DATA[("Supabase data and experiment results")]
```

The diagram shows logical responsibilities. Backend tools enforce data access. Read the Agents and Guardrails pages for the internal execution path.

## Initial scope

The initial product supports one cooling zone, one supervisor agent, and two specialist agents. It uses precomputed simulation results or uploaded telemetry. An operator receives an evidence-backed comparison and decides whether to investigate or adopt a recommendation.

| Included in the MVP | Later extension |
|---|---|
| Inspect telemetry and data quality | Site-specific BMS connector |
| Calculate energy and compare a documented baseline | On-demand simulation worker |
| Retrieve and rank compatible precomputed experiments | Calibrated predictive models |
| Explain results with evidence references | Operational trial and savings verification |
| Enforce request, tool, and recommendation guardrails | Automated equipment control, subject to a separate design |
| Record case state, tool events, and validation outcomes | Larger-scale monitoring infrastructure |

The MVP has no RAG, vector database, document-retrieval pipeline, or knowledge graph. Skills are procedural agent instructions, not a knowledge base. Equipment limits are versioned application configuration, not values invented by an LLM.

## Project status

This is a design specification; implementation has not started. It replaces the earlier MPC-centered architecture. The original course proposal PDF remains a historical requirement reference, and alignment with that proposal must be reviewed as the project develops.

The longer architecture is backed up in [the pre-split document](../../archive/architecture-before-split-2026-10-31.md). The original proposal PDF remains in its existing project folder.

Next: [02 — Agents](02-agents.md)
