# 06 — Monitoring and Evaluation

[Architecture index](../../architecture.md)

Use this page to define logs, case visibility, and meaningful success checks.

## Monitoring

Use one `case_id` and `trace_id` across the API, supervisor, specialists, and tools. Add `step_id` and `parent_step_id` to reconstruct parent/child execution. Events record timestamps, duration, actor/tool name, status, model/skill/policy versions, usage when available, evidence IDs, and typed errors. Record observable actions and outcomes rather than hidden model reasoning.

Streamlit includes a monitoring page for failed cases, latency, model/tool usage, missing-data cases, guardrail rejections, and case drill-down. Python console logging remains useful if the monitoring database itself is unavailable. Report incomplete audit persistence explicitly; do not leave a case marked successfully persisted when storage failed.

## Evaluation

Evaluate three distinct layers:

1. **Tools and guardrails:** energy arithmetic, authorization, units, unsupported scenarios, insufficient temperature observability, incompatible experiments, timeouts, and retries.
2. **Agent behavior:** correct tool selection, evidence support, completion rate, abstention on missing evidence, latency, and usage. Compare with direct Python selection using the same data and rules.
3. **Cooling outcomes:** evaluate selected settings with the simulator or a controlled site trial. Report total energy, cooling energy, temperature-constraint behavior, and scope separately. Precomputed results demonstrate only the scenarios actually evaluated.

A savings target is an experimental hypothesis, not an architectural guarantee. Baseline and candidate runs must share relevant conditions. Any later learned surrogate must be tested on held-out cases and cannot grade its own proposed control policy without independent evaluation.

Next: [07 — Deployment and Roadmap](07-deployment-and-roadmap.md)
